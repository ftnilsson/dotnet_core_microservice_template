using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MyProject.API.Application.Queries.GetItems;
using Xunit;

namespace MyProject.UnitTests.Application.Queries
{
    public class GetItemsQueryHandlerTests
    {
        private readonly GetItemsQueryHandler _handler = new();

        [Fact]
        public async Task Handle_ReturnsAtLeastOneItem()
        {
            var result = await _handler.Handle(new GetItemsQuery(), CancellationToken.None);

            Assert.NotEmpty(result);
        }

        [Fact]
        public async Task Handle_ReturnedItems_HaveNonEmptyNames()
        {
            var result = await _handler.Handle(new GetItemsQuery(), CancellationToken.None);

            Assert.All(result, item => Assert.False(string.IsNullOrWhiteSpace(item.Name)));
        }
    }
}
