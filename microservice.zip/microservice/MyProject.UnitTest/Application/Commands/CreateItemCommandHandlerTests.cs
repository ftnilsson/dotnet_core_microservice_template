using System.Threading;
using System.Threading.Tasks;
using MyProject.API.Application.Commands.CreateItem;
using Xunit;

namespace MyProject.UnitTests.Application.Commands
{
    public class CreateItemCommandHandlerTests
    {
        private readonly CreateItemCommandHandler _handler = new();

        [Fact]
        public async Task Handle_ReturnsNewId()
        {
            var command = new CreateItemCommand("Test Item", "A description");

            var id = await _handler.Handle(command, CancellationToken.None);

            Assert.True(id > 0);
        }
    }
}
