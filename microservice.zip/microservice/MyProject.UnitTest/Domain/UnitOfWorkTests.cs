using System.Threading;
using System.Threading.Tasks;
using MyProject.Domain.Common;
using NSubstitute;
using Xunit;

namespace MyProject.UnitTests.Domain
{
    /// <summary>
    /// Demonstrates NSubstitute usage with IUnitOfWork.
    /// Replace this with tests for your real aggregate/service implementations.
    /// </summary>
    public class UnitOfWorkTests
    {
        [Fact]
        public async Task SaveChangesAsync_IsCalled_WhenWorkIsCommitted()
        {
            var uow = Substitute.For<IUnitOfWork>();
            uow.SaveChangesAsync(Arg.Any<CancellationToken>()).Returns(1);

            var rowsAffected = await uow.SaveChangesAsync(CancellationToken.None);

            Assert.Equal(1, rowsAffected);
            await uow.Received(1).SaveChangesAsync(Arg.Any<CancellationToken>());
        }
    }
}
