﻿#API endpoints

Just a normal api that will act on the domian through the ApplicationLayer's Commands, queries and EventHandlers.

