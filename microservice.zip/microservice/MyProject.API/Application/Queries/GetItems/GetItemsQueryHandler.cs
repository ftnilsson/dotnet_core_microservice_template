using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using MyProject.API.Application.ViewModels;

namespace MyProject.API.Application.Queries.GetItems
{
    public class GetItemsQueryHandler : IRequestHandler<GetItemsQuery, IEnumerable<ItemViewModel>>
    {
        // TODO: inject IRepository<Item> or a query-side read service here
        public GetItemsQueryHandler() { }

        public Task<IEnumerable<ItemViewModel>> Handle(GetItemsQuery request, CancellationToken cancellationToken)
        {
            // TODO: replace with real data retrieval
            IEnumerable<ItemViewModel> items = new[]
            {
                new ItemViewModel { Id = 1, Name = "Sample Item", Description = "Replace with real data from your repository" }
            };

            return Task.FromResult(items);
        }
    }
}
