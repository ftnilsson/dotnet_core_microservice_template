using System.Collections.Generic;
using MediatR;
using MyProject.API.Application.ViewModels;

namespace MyProject.API.Application.Queries.GetItems
{
    public record GetItemsQuery : IRequest<IEnumerable<ItemViewModel>>;
}
