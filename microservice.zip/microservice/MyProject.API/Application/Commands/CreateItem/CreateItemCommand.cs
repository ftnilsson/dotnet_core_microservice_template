using MediatR;

namespace MyProject.API.Application.Commands.CreateItem
{
    public record CreateItemCommand(string Name, string Description) : IRequest<int>;
}
