using System.Threading;
using System.Threading.Tasks;
using MediatR;

namespace MyProject.API.Application.Commands.CreateItem
{
    public class CreateItemCommandHandler : IRequestHandler<CreateItemCommand, int>
    {
        // TODO: inject IRepository<Item> and IUnitOfWork here
        public CreateItemCommandHandler() { }

        public Task<int> Handle(CreateItemCommand request, CancellationToken cancellationToken)
        {
            // TODO: create and persist your aggregate here, then return the new entity Id
            // Example:
            //   var item = new Item(request.Name, request.Description);
            //   await _repository.AddAsync(item, cancellationToken);
            //   await _unitOfWork.SaveChangesAsync(cancellationToken);
            //   return item.Id;

            return Task.FromResult(1); // stub — replace with real Id
        }
    }
}
