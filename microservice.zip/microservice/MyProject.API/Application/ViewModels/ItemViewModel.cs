namespace MyProject.API.Application.ViewModels
{
    public class ItemViewModel
    {
        public int Id { get; init; }
        public string Name { get; init; }
        public string Description { get; init; }
    }
}
