﻿#View models

Is an aggregatin of all data rquired by a specific view/ or end point and can be a combination of domain entities.


