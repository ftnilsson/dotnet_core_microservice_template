﻿using System.Threading;
using System.Threading.Tasks;

namespace MyProject.Domain.Common
{
    public interface IUnitOfWork
    {
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    }
}
