#Domain validation

domain validation could implement the ISpecification which helps in always keeping the domian in a valid state.

	public class OrderCreationSpecification : INotification
	{
		...
	}
	