﻿#Queries

Can act fetch data directly from the infrastructure layer and will not change anything in the domain.