﻿namespace MyProject.Domain.Common
{
    public interface IUnitOfWork
    {
    }
}
